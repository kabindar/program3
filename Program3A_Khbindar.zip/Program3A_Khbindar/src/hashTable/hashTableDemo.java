package hashTable;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class hashTableDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	      
		Scanner scan = new Scanner(System.in);
	    hashTable hash = new hashTable(
	    		);
		char ch;
		
		do    
	        {   
	            System.out.println("\nHash Table Operations\n");
	            System.out.println("1. Insert");
	            System.out.println("2. Delete");
	            System.out.println("3. Search");
	 
	            int choice = scan.nextInt();            
	            switch (choice)
	            {                         
	            case 1 :
	            	int count = 0;
	            	System.out.println("Enter number of integers to be inserted:" );
	            	int input = scan.nextInt();
	            	count = input;
	            	int[] arrVal = new int[count];
	            	for (int i = 0; i < count; i++) {
	            		System.out.print("Enter interger " + (i+1) + ": ");
	            		input = scan.nextInt();
	            		//count = input;
	            		arrVal[i] = input;
	            		hash.keyVal(i,input);
	            	}
	            	
	            	
	            	for (int i = 0; i < arrVal.length; i++) {
	            		hash.insert(arrVal[i]);
	            	}
	            	
	                                 
	                break;                         
	            case 2 : 
	            	System.out.println("Enter integer element to delete");
	                input = scan.nextInt();
	                hash.delete(input);
	                break; 
	            case 3 : 
	            	 System.out.println("Enter integer element to search");
	            	 input = scan.nextInt();
	            	 boolean result = hash.search(input);
	            	 if (result) {
	            		 System.out.println("Variable exists");
	            	 }
	            	 else {
	            		 System.out.println("Variable not found");
	            	 }
	                break;  
	            default : 
	                System.out.println("Wrong Entry \n ");
	                break;   
	            }
	            
	            hash.printHash();
	            
	            System.out.println();
	            System.out.println();
	            System.out.println("\nDo you want to continue (Type y or n) \n");
	            ch = scan.next().charAt(0); 
	             
	 
	        } while (ch == 'Y'|| ch == 'y');               
	 
	}

}
