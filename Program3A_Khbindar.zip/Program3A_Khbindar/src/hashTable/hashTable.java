package hashTable;

import java.util.Arrays;


public class hashTable {
	
	private static int DEFAULT_TABLE_SIZE = 10;
	int[] newArr;
	int[] keyValArr = new int[DEFAULT_TABLE_SIZE];


	public int[] keyValArr (int k, int v) 
	{
			keyValArr[k] = v;
	
		
		return keyValArr;
	}
	
	
	public int keyVal (int k, int v) {
		int key = k;
		int val = v;
		return val;
	}

	
	public hashTable()
    {
	    this.newArr = new int[DEFAULT_TABLE_SIZE];
    }
	
	
	
    public void insert(int val)
    {
    	int key = hash(val) ;
    	if(this.newArr[key] == 0) {
    		this.newArr[key] = val;
    		keyValArr(key, val);
    	}
    	else {
    	    int count = 1;
    		while(this.newArr[key] != 0) {
    			key = hash(val) ;
    			
    			key = quadProbe(key,count);
    			count++;
    		
    		}
            
    			this.newArr[key] = val;
    			keyValArr(key, val);
    		}
    	
    	
    	
    	
    	double arrCount = 0.0;
    	for (int i = 0; i < newArr.length ; i++) {
    		if(newArr[i] != 0) {
    			arrCount++; 
    		}
    	}
    	
    	
    	if (arrCount / newArr.length == .8 ) {
    		newArr = reHash(keyValArr);
    	 	//System.out.println(Arrays.toString(newArr));
    	 	
    	}
    	
    	}
    public int hash(int val) {
    	
    	return val % DEFAULT_TABLE_SIZE;
    	
    }
    
    public int quadProbe(int key, int count) {

    	key = key + (count*count);
    	
    	if ( key > DEFAULT_TABLE_SIZE) {
    		int newKey = key % DEFAULT_TABLE_SIZE;
            
    	    return newKey;	
    	}
   
    	
    	return key;
    	
    }
    
    public int[] reHash(int[] newArr) {
    	int size = DEFAULT_TABLE_SIZE;
    	DEFAULT_TABLE_SIZE = DEFAULT_TABLE_SIZE * 2;
    	 int[] temp = new int [DEFAULT_TABLE_SIZE]; 
    	int[] key = new int [newArr.length];
    	int[] val = new int [newArr.length];
    	
    	for (int i = 0; i < newArr.length; i++) {
    		if (newArr[i] != 0) {
    			key[i] = i;
    			val[i] = newArr[i];
    			}
    		}
    	for(int i = 0; i < newArr.length; i++) {
    		  if(temp[i] == 0 )  {
    			  
    			  temp[key[i]] = val[i];
    		        
    		        
    		       
    		}
    	}
    	return temp;
        
    }
   
    
    public void printHash() {
    	System.out.println("Key \t Value");
    	for(int i = 0; i < newArr.length; i++) {
    		System.out.println(i + "\t   " + newArr[i] );
    	}
    
    }


	public void delete(int input) {
		// TODO Auto-generated method stub
		for(int i = 0; i < DEFAULT_TABLE_SIZE; i++) {
    		if (newArr[i] == input) {
    			newArr[i] = 0;
    		}
    	}
		System.out.println(Arrays.toString(newArr));
	}
	
	public boolean search(int input) {
		for(int i = 0; i < DEFAULT_TABLE_SIZE; i++) {
    		if (newArr[i] == input) {
    			return true;
    		}
		}
      return false;
	}
   

}