package prog3;

import java.util.Arrays;
import java.util.Collections;
import java.io.IOException;
import java.util.ArrayList;

public class makeChange {

	public static Object[] input(int val, Integer[] coins) {
		if(isEmpty(coins) == true) {
			throw new IllegalArgumentException("Array values should be greater than 0");
		}
		
		if(nullArr(coins) == true) {
			throw new NullPointerException("Array values can't be null ");
		}
		
		if(inputError(val) == true) {
			throw new NumberFormatException("Input can't be less than 0");
		}
		
		
		Arrays.sort(coins, Collections.reverseOrder());
        ArrayList<Integer> arrList = new ArrayList<Integer>();
	
		for( int i=0; i< coins.length; i++ ) 
	          while(val >= coins[i])
	          {
	            val= val - coins[i];
	            arrList.add(coins[i]);
	          }
	
	        
	        Object[] newArr = arrList.toArray();
	     
	        return newArr;
	}
	
	
	public static boolean isEmpty(Integer[] coins) {
		boolean empty = true;
		for (int i=0; i<coins.length; i++) {
		  if (coins[i] != 0) {
		    empty = false;
		    return empty;
		  }
		}
	    return empty;
	}
	
	public static boolean nullArr(Integer[] coins) {
		boolean empty = true;
		for (int i=0; i<coins.length; i++) {
		  if (coins[i] != null) {
		    empty = false;
		    return empty;
		  }
		}
	    return empty;
	}
	
	public static boolean inputError(int i) {
		boolean empty = true;
		  if (i >= 0) {
		    empty = false;
		    return empty;
		  }
	    return empty;
	}
	
	

}
