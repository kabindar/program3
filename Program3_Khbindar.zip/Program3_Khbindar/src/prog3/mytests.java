package prog3;


import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


class mytests {

	@Test
	  void emptyArr() {
		 
	    Assertions.assertThrows(IllegalArgumentException.class, () -> {
	        Integer[] testArr = new Integer[] {0,0,0,0};
		    makeChange.input(42, testArr);
	    });
	  }
	
	@Test
	  void nullArr() {
		 
	    Assertions.assertThrows(NullPointerException.class, () -> {
	    	Integer[] coins = new Integer[] {null} ;
		    makeChange.input(42, coins);
	    });
	  }
	
	@Test
	  void wrongInput() {
		 int i = -42;
	    Assertions.assertThrows(NumberFormatException.class, () -> {
	    	Integer[] coins = new Integer[] {5,10,25,1} ;
		    makeChange.input(i, coins);
	    });
	  }
	
	
	
	@Test
	void Change42Usa () {
		Integer[] coins = new Integer[] {1,5,10,25} ;
		Integer[] expected = new Integer[] {25,10,5,1,1};
		assertArrayEquals(expected,makeChange.input(42, coins));
	}

}
